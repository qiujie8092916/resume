var device_task = function(){
	device_task_tbody("SELECT id, client_id, client_pcname, client_ip, mac_addr, status FROM conn_info WHERE status='idle'")
	cmd_case("SELECT name FROM Case_Dispatcher.case_info ORDER BY name")
}

var task_status = function(){
	var sql = "select * from (SELECT a.id, a.exc_client_id, case_info.name AS cmd, c.client_ip, c.client_pcname, a.start_time, a.status, a.reserved \
		FROM (SELECT * FROM case_cmd_pool ORDER BY case_cmd_pool.id desc) a \
		INNER JOIN case_info ON case_info.id=a.case_id \
		INNER JOIN (select * from (SELECT * FROM conn_info ORDER BY id desc) cc GROUP BY cc.client_id ORDER BY cc.id desc) c ON c.client_id=a.exc_client_id \
		order by a.id desc) re group by re.exc_client_id"
	task_status_tbody(sql)
}

var device_task_tbody = function(sql){
	$("#device-list").bootstrapTable('destroy')
	$("#device-list").bootstrapTable({
		toolbar: '#toolbar',
		undefinedText: '---',
		cache: false,
		pagination: true,
		showRefresh: true,
		showColumns: true,
		search: true,
		sidePagination: 'server',
		url: "php/bootstrap-server.php",
		method: 'post',
		contentType: "application/x-www-form-urlencoded",
		queryParams: function getParams(params){
				params.sql_cmd = sql
				return params
		},
		columns: [
			{
				field: "select",
				checkbox: true,
				width: 50,
				align: "center",
				valign: "bottom"
			}, {
				title: "Device list",
				field: "client_pcname"
			}, {
				title: "IP",
				field: "client_ip"
			}, {
				title: "MAC",
				field: "mac_addr"
			}, {
				title: "Status",
				field: "status"
			}
		],
		
		onPreBody: function(){
			$("div.main").append("<div class='loaders'><div class='loader'><div class='loader-inner ball-pulse'><div style='background: #F0E797'></div><div style='background: #FF9D84'></div><div style='background: #87CDCD'></div></div></div></div>")
			$(".loaders").css("height", $(window).height()-50)
			$(".tab-pane").addClass("loader_blur")
		},
		
		onLoadSuccess: function(){
			$("div.main").find(".loaders").remove()
			$(".tab-pane").removeClass("loader_blur")
		},
		
		onLoadError: function (status) {
				alert("Query failed from Mysql database!")
		}
	})
}

var task_status_tbody = function(sql){
	var ap = "<table class='item_detail table table-no-bordered'></table>" //
	$("#task-status").bootstrapTable('destroy')
	$("#task-status").bootstrapTable({
		undefinedText: '---',
		cache: false,
		pagination: true,
		showRefresh: true,
		//showColumns: true,
		search: true,
		detailView: true,
		sidePagination: 'server',
		url: "php/bootstrap-server.php",
		method: 'post',
		contentType: "application/x-www-form-urlencoded",
		queryParams: function getParams(params){
				params.sql_cmd = sql
				return params
		},
		columns: [
			{
				title: "ID",
				field: "id"
			}, {
				title: "Host Name",
				field: "client_pcname"
			}, {
				title: "Device IP",
				field: "client_ip"
			}, {
				title: "CMD",
				field: "cmd"
			}, {
				title: "Last Update Time",
				field: "start_time"
			}, {
				title: "Status",
				field: "status",
				formatter: status_formater
			}, {
				title: "Result ",
				field: "reserved"
			}
		],
		
		onPreBody: function(){
			$("div.main").append("<div class='loaders'><div class='loader'><div class='loader-inner ball-pulse'><div style='background: #F0E797'></div><div style='background: #FF9D84'></div><div style='background: #87CDCD'></div></div></div></div>")
			$(".loaders").css("height", $(window).height()-50)
			$(".tab-pane").addClass("loader_blur")
		},
		
		onLoadSuccess: function(){
			$("div.main").find(".loaders").remove()
			$(".tab-pane").removeClass("loader_blur")
		},
		
		onLoadError: function (status) {
				alert("Query failed from Mysql database!")
		},
		
		onExpandRow: function (index, row, $detail) {
			var sql = "SELECT a.id, a.exc_client_id, case_info.name AS cmd, c.client_ip AS device_ip, c.client_pcname AS device_hostname, a.start_time, a.status, a.reserved \
				FROM (SELECT * FROM case_cmd_pool ORDER BY case_cmd_pool.id desc) a \
				INNER JOIN case_info ON case_info.id=a.case_id \
				INNER JOIN (select * from (SELECT * FROM conn_info ORDER BY id desc) cc GROUP BY cc.client_id ORDER BY cc.id desc) c ON c.client_id=a.exc_client_id \
				WHERE a.exc_client_id="+row.exc_client_id+" \
				order by a.id desc"
			
			$.when(defer("php/read-db.php", {sql_cmd: sql})).done(function(data){
				var json_result = eval('(' + data + ')')
				var el = ""
				for(var i = 0; i < json_result.length; i++){
					if(json_result[i].id != row.id){
						for(var j in json_result[i]){
							if(json_result[i][j] == null){
								json_result[i][j] = "---"
							}
						}
						el += "<tr><td></td>\
							<td>"+json_result[i].id+"</td>\
							<td>"+json_result[i].device_hostname+"</td>\
							<td>"+json_result[i].device_ip+"</td>\
							<td>"+json_result[i].cmd+"</td>\
							<td>"+json_result[i].start_time+"</td>\
							<td><span class="+json_result[i].status+">"+json_result[i].status+"</span></td>\
							<td>"+json_result[i].reserved+"</td>\
							</tr>"
					}
				}
				$(".item_detail").append(el)
				
				$(".item_detail tr:eq(0) td").each(function(i, e){
					$(this).css("width", $(this).parents(".detail-view").prev("tr").children("td:eq("+(i)+")").width())
				})
			})
		},
		
		detailFormatter: function (index, row){
			return ap
    }
	})
}

var cmd_case = function(sql){
	$.when(defer("php/read-db.php", {sql_cmd: sql})).done(function(data){
		var json_result = eval('(' + data + ')')
		var ap = ""
		for(var i = 0; i < json_result.length; i++){
			ap += "<option value='"+json_result[i].name+"'>"+json_result[i].name+"</option>"
		}
		
		$("#cmd_list").append(ap)
		var config_modal = '<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="configuration" data-backdrop="static">\
													<div class="modal-dialog" role="document">\
														<div class="modal-content">\
															<div class="modal-header">\
																<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>\
																<h4 class="modal-title" id="configuration">Case Configuration</h4>\
															</div>\
															<div class="modal-body">\
															</div>\
															<div class="modal-footer">\
																<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>\
																<button type="button" class="btn btn-primary">Save</button>\
															</div>\
														</div>\
													</div>\
												</div>'
		$('body').append(config_modal)
		
		$('#cmd_list').multiselect({
			//enableFiltering: true,
			//enableCaseInsensitiveFiltering: true,
			maxHeight: $(window).height()/2,
			nonSelectedText: 'CMD Selected',
			onChange: function(element, checked) {
				if(checked === true){
					$('#myModal').off('show.bs.modal').on('show.bs.modal', function(e){
						$.when(defer("/191_Cmd_Case/"+element.val()+"/config.py")).done(function(data){
							var json_result = data.split("\n")
							var ap = compose_result(json_result)
							$('.modal-body').append(ap)
						})
					})
					$('#myModal').modal("show")
				} else{
					$("#myModal").modal("hide")
				}
				$('#myModal').off('hidden.bs.modal').on('hidden.bs.modal', function(e){
					$(".modal-body").empty()
				})
			}
		})
		
		
	})
}

var compose_result = function(array){
	var appendhtml = '<form class="form-horizontal">'
	for(var i = 0; i < array.length; i++){
		if(array[i].trim() != "" && array[i].trim().indexOf("#") != 0 && array[i].trim().indexOf("__all__") != 0){
			array[i] = array[i].trim()
			var key = array[i].substring(0, array[i].indexOf("="))
			var value = array[i].substring(array[i].indexOf("=")+1)
			if((value.indexOf("\"") == 0 && value.lastIndexOf("\"") == value.length-1) || (value.indexOf("\'") == 0 && value.lastIndexOf("\'") == value.length-1)){
				value = value.substring(1, value.length-1)
			}
			appendhtml +=  '<div class="form-group">\
												<label for="'+key+'" class="col-sm-2 control-label">'+key+'</label>\
												<div class="col-sm-10">\
													<input type="text" class="form-control" id="'+key+'" value="'+value+'">\
												</div>\
											</div>'
		}
	}
	appendhtml += "</form>"
	return appendhtml
}

var status_formater = function(value, row, index){   
	return "<span class='"+value+"'>"+value+"<span>"
}

function defer(url, data){
	var df = $.Deferred();
	$.ajax({
		type: "post",
 		url: url,
		data: data,
		async: false,
		success: function(data, textStatus){df.resolve(data);}
	});
	return df.promise();
}