<?php
$sql = $_POST["sql_cmd"];

$con = mysqli_connect('10.37.132.191', 'root', '123456', 'Case_Dispatcher');
if(!$con){
  die("Could not connect: " . mysqli_connect_error());
}

$sql_cmds = explode(';',$sql); 
$json_array = array();
$result_array = array();
$cnt=0;
foreach ($sql_cmds as $sql_cmd){
    $result = mysqli_query($con, $sql_cmd);
    if(! $result){echo "MySql Error:".mysqli_error($con);exit();}
    while($row = mysqli_fetch_assoc($result)){
				array_push($result_array, $row);
				$cnt++;
    }
}
$json_array["rows"] = $result_array;
$json_array["total"] = $cnt;

$json_string = json_encode($json_array);
echo $json_string;
mysqli_close($con);
?>
