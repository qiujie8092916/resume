<?php
$sql = $_POST["sql_cmd"];
$con = new mysqli('10.37.132.191', 'root', '123456','Case_Dispatcher');
if (!$con)
  {
  die("Could not connect: " . mysql_error());
  }
//$db_selected = mysql_select_db("CI", $con);

$sql_cmds = explode(';',$sql); 
$json_array = array();
foreach ($sql_cmds as $sql_cmd){
    $result = mysqli_query($con, $sql_cmd);
    if(! $result){echo "MySql Error:\n".mysqli_error();exit();}
    while($row = mysqli_fetch_assoc($result)){
        $json_array[] = $row;
    }
}
$json_string = json_encode($json_array);
echo $json_string;
mysqli_close($con);
?>
