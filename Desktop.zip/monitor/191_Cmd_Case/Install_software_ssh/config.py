#! /usr/bin/env python2


#type= ["SW_INSTALL","PROCESS_MINITOR","SYSTEM REBOOT","SERVICE RESTART",CUSTOMIZE_SCRIPT]


#cmd_type="PROCESS_MINITOR"
#name="check service status:ping"
#commnad="ps -a |grep ping"
#parameter="ssh"
#pass_keyword="ping"
 

cmd_type="SW_INSTALL"
name="install a sw:ssh"
command="apt-get install -y ssh"
parameter="ssh"
pass_keyword="is already the newest version;Setting up ssh"

#cmd_type="CUSTOMIZE_SCRIPT"
#name="user defined script for client PC"
#commnad="python"
#parameter=""
#pass_keyword=""



__all__ = ["cmd_type","name","command","parameter","pass_keyword"]


