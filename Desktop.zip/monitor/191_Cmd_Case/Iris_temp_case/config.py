#! /usr/bin/env python2


#type= ["SW_INSTALL","PROCESS_MINITOR","SYSTEM REBOOT","SERVICE RESTART",]


cmd_type="PROCESS_MINITOR"
name="check service status:ping"
commnad="ps -a |grep ping"
parameter=""
pass_keyword="ping"
 

#cmd_type="SW_INSTALL"
#name="install a sw:ssh"
#commnad="apt-get install -y ssh"
#parameter=""
#pass_keyword="is already the newest version;Setting up ssh"

__all__ = ["cmd_type","name","commnad","parameter","pass_keyword"]


